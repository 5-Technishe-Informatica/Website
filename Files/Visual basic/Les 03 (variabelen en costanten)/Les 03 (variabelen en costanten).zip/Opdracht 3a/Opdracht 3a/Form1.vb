﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim tekst As String
        tekst = TextBox1.Text
        Label3.Text = tekst
        tekst = TextBox2.Text
        Label4.Text = tekst
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub
End Class
